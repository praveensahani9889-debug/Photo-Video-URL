<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }
$status = isset($errorStatus) ? (int)$errorStatus : 400;
$text = (isset($errorMessage) && $errorMessage !== '') ? $errorMessage : (($status === 415) ? 'This file type cannot be displayed.' : 'This link is not valid.');
$title = ($status === 415) ? 'Unsupported file type' : 'Invalid link';
render_viewer(array(
    'status' => $status,
    'title'  => $title,
    'class'  => 'v-error',
    'body'   => '<main class="err"><h1>' . h($title) . '</h1><p>' . h($text) . '</p></main>',
));
