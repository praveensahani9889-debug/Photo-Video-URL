<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }
$status = isset($errorStatus) ? (int)$errorStatus : 503;
$text = (isset($errorMessage) && $errorMessage !== '') ? $errorMessage : (($status === 415) ? 'This file type cannot be displayed.' : 'The service is temporarily unavailable. Please try again in a moment.');
$title = ($status === 415) ? 'Unsupported file type' : 'Temporarily unavailable';
render_viewer(array(
    'status' => $status,
    'title'  => $title,
    'class'  => 'v-error',
    'body'   => '<main class="err"><h1>' . h($title) . '</h1><p>' . h($text) . '</p></main>',
));
