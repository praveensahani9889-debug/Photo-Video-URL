<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

return [
    'site_name'    => 'Photo Video URL',
    'site_url'     => 'https://ivu.gt.tc',   // canonical base, no trailing slash
    'support_email'=> 'praveensahani9273@gmail.com',
    'last_updated' => '6 November 2026',

    // Leave empty until an official APK or Play Store URL exists.
    'app_download_url' => '',

    // Exact Supabase host, e.g. 'abcdefghijkl.supabase.co'.
    // If empty, any https://<ref>.supabase.co/storage/v1/object/public/... URL is accepted.
    // Setting it is strongly recommended.
    'supabase_host' => '',

    // Seconds. Keep these short so disabled links stop working quickly.
    'cache_ttl'     => 60,   // active records
    'negative_ttl'  => 10,   // missing / inactive records
    'http_timeout'  => 6,    // Firebase request timeout
];
