<?php
// Firebase Web App configuration (public configuration, NOT a secret).
// The website only performs unauthenticated, read-only REST GET requests
// against photo_video_url/public_links/{id}. Never put Admin SDK keys here.
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

return [
    'apiKey'            => 'AIzaSyAvji79wQmkYBO5nIsC1Y3LxfKw0K-EZg0',
    'authDomain'        => 'photo-video-url.firebaseapp.com',
    'databaseURL'       => 'https://photo-video-url-default-rtdb.firebaseio.com',
    'projectId'         => 'photo-video-url',
    'storageBucket'     => 'photo-video-url.firebasestorage.app',
    'messagingSenderId' => '411751765755',
    'appId'             => '1:411751765755:web:181af3da7e9961bc29425e',
    'measurementId'     => 'G-96M68YDCSN',

    // Where the Android app publishes public link records (checked in this order).
    // The current app writes to the database root: public_links/{shortId}
    'links_paths'       => array('public_links', 'photo_video_url/public_links'),
];
