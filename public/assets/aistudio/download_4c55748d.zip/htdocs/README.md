# Photo Video URL - public media viewer and website

PHP site for InfinityFree (`https://ivu.gt.tc`). It has two separate experiences:

1. **Informational website**: `/`, `/about`, `/features`, `/how-it-works`, `/terms`, `/privacy`, `/disclaimer`, `/contact`, `/faq`
2. **Direct media viewer**: `/image_ID`, `/video_ID`, `/document_ID`, `/file_ID`, `/apk_ID` (no header, nav or footer)

Flow: ID from the path -> Firebase RTDB REST read of `photo_video_url/public_links/{id}` -> validate -> show media straight from Supabase. The server never proxies or re-uploads media.

## Files

```
.htaccess            clean URLs, HTTPS, blocks internal folders
index.php            single entry point and router
config/firebase.php  Firebase web config + links path
config/site.php      site URL, email, app download URL, Supabase host, cache TTLs
app/                 security, cache, firebase_client, resolver, media_handler, site, pages
errors/              400/404/410/503 viewer error pages
assets/              css, js, logo images
robots.txt, sitemap.xml, favicon.ico
```

## Deploy on InfinityFree

1. In the control panel open File Manager (or use FTP) and go to `htdocs/`.
2. Delete the old Site.pro files (`sitepro/`, `index2.html`, `web.config`, old `index.php`, old `.htaccess`). This site does not use them.
3. Upload the **contents** of this folder into `htdocs/` (so `htdocs/index.php` and `htdocs/.htaccess` exist). Make sure `.htaccess` was uploaded (hidden file).
4. Make sure `htdocs/cache/` is writable (default 755 is normally fine).
5. Edit `config/site.php`:
   - `supabase_host`: set to your exact Supabase host (e.g. `abcdefgh.supabase.co`). Strongly recommended.
   - `app_download_url`: leave empty until an official APK or Play Store URL exists.
6. Open `https://ivu.gt.tc/` (landing page) and then a real short link.

If you get a redirect loop, remove the 3 HTTPS lines at the top of `.htaccess`.
Errors are written to the host's `error_log` (blocked from the web); visitors only see generic pages.

## Firebase rules (important)

The site reads without authentication, so only `public_links` entries should be publicly readable, one record at a time:

```json
{
  "rules": {
    ".read": false,
    "photo_video_url": {
      "public_links": {
        "$id": { ".read": true, ".write": false }
      }
    }
  }
}
```

Keep whatever *write* rules your Android app already needs for its other paths. Writes must never be public. Check your app's current rules before publishing so you do not break uploads. Do not make the whole database readable.

## Schema assumptions

`public_links/{id}` fields read: `originalUrl` (or `url`), `mimeType`, `fileType`, `storagePath`, `active`. A record with `active: false` returns HTTP 410. If `fileType` is present it must equal the URL prefix (`image`, `video`, ...). If your app writes different key names or values, change `normalize_record()` in `app/resolver.php` only.

## Behaviour

- Image / video: minimal HTML page, media only, Open Graph tags (`og:image` for images).
- PDF (`document_` with PDF MIME): inline in an iframe; browsers without a PDF viewer get a download instead.
- Other documents, `file_`, `apk_`: 302 to the validated Supabase URL with `?download=<filename>` so the browser downloads under the right name. Nothing is executed or installed.
- Only `https://*.supabase.co/storage/v1/object/public/...` (or your exact host) is accepted. No URLs are taken from query strings.
- Metadata cache: 60 s for active records, 10 s for missing/disabled. HTML pages: `max-age=60`. A disabled link stops working within about two minutes.
- Viewer pages send `noindex`.

## Testing checklist

1. Valid image URL: only the image, centered, no distortion (portrait + landscape).
2. Valid video URL: player with controls, play/pause/seek works.
3. Document URL: PDF shows inline on desktop; non-PDF downloads.
4. APK URL: downloads as `*.apk`, nothing installs by itself.
5. Invalid ID (`/image_!!`, `/image_a`): 404 page (never an info-site layout).
6. Inactive link (`active: false`): 410 "Link disabled".
7. Missing record: 404.
8. Supabase unavailable / file deleted: image/video shows "could not be loaded"; wrong host in `originalUrl` gives 404.
9. Mobile Chrome (Android): image, video, PDF fallback download, menu on info pages.
10. Desktop Chrome: same, plus refresh on every info route (`/faq`, `/terms`, ...).
11. WhatsApp preview: send a link in a chat. Previews are not guaranteed; the crawler caches results.
12. Cache: open a link, set `active:false` in Firebase, reload after ~1-2 minutes: must be 410.
13. Firebase down/permission denied: 503 page, no technical details.
14. `/app/`, `/config/site.php`, `/cache/` return 403; no directory listings.
15. `curl -I https://ivu.gt.tc/image_AaBb123` should return headers with `X-Robots-Tag` and CSP.

## Known limits

- InfinityFree may show a browser-check page to automated clients (crawlers, curl). If link previews never appear, that is the likely cause and it cannot be fixed from PHP.
- Legal pages describe the app from the project brief. Review them against what the app really does before publishing.
