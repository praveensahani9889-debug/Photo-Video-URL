<?php
/**
 * Photo Video URL - single entry point.
 *  - Informational website:  /, /about, /features, /how-it-works, /terms, /privacy, /disclaimer, /contact, /faq
 *  - Direct media viewer:    /image_xxx, /video_xxx, /document_xxx, /file_xxx, /apk_xxx
 */
define('APP_ROOT', __DIR__);
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
error_reporting(E_ALL);

require APP_ROOT . '/app/security.php';
require APP_ROOT . '/app/cache.php';
require APP_ROOT . '/app/firebase_client.php';
require APP_ROOT . '/app/media_handler.php';
require APP_ROOT . '/app/resolver.php';
require APP_ROOT . '/app/site.php';

function fatal_503()
{
    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/plain; charset=UTF-8');
        header('Cache-Control: no-store');
        header('Retry-After: 60');
    }
    echo 'Service temporarily unavailable.';
    exit;
}

set_exception_handler(function ($e) {
    log_internal('exception: ' . get_class($e) . ' ' . $e->getMessage());
    fatal_503();
});
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        log_internal('fatal: ' . $e['message']);
        if (!headers_sent()) { fatal_503(); }
    }
});

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
if ($method !== 'GET' && $method !== 'HEAD') {
    http_response_code(405);
    header('Allow: GET, HEAD');
    exit;
}

$path = request_path();
if ($path === null) { send_error(400); }

if ($path === '/index.php') {
    header('Location: /', true, 301);
    exit;
}

$routes = info_routes();
if (isset($routes[$path])) { serve_info_page($path); exit; }

$media = parse_media_id($path);
if ($media !== null) { resolve_media($media); exit; }

serve_info_page($path); // unknown path -> branded 404 page (status 404)
