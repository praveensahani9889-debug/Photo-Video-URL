(function () {
  var img = document.querySelector('img');
  var vid = document.querySelector('video');
  var msg = document.getElementById('msg');
  function fail() { if (msg) { msg.hidden = false; } }
  if (img) { img.addEventListener('error', function () { img.hidden = true; fail(); }); }
  if (vid) { vid.addEventListener('error', function () { vid.hidden = true; fail(); }, true); }
  // Browsers without an inline PDF viewer (e.g. many Android browsers): download instead of a blank frame.
  var frame = document.querySelector('iframe[data-dl]');
  if (frame && navigator.pdfViewerEnabled === false) { location.replace(frame.getAttribute('data-dl')); }
})();
