<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

/* Content for the informational website. Every page returns array(title, description, body). */

function faq_items()
{
    $e = h(cfg('site')['support_email']);
    return array(
        array('How do I upload a file?',
              'Use the Photo Video URL Android app. Choose an image, video, document, file or APK, upload it, and the app gives you a short link. This website does not accept uploads.'),
        array('What is a short URL?',
              'A short URL such as <code>https://ivu.gt.tc/image_AaBb123</code> is a compact address for one uploaded file. The part after the slash is a short ID that starts with the file category (image, video, document, file or apk).'),
        array('Where are my files stored?',
              'The files themselves are stored in Supabase Storage. Firebase Realtime Database stores the small record that connects a short ID to the stored file. This website reads that record and shows the file.'),
        array('Who can open a public link?',
              'Anyone who has the link. Links are not protected by a password, so share them only with people you are comfortable giving access to.'),
        array('Why does my link show an error?',
              'The ID may have been mistyped or cut off when the link was copied, the link may have been disabled, or the storage service may be temporarily unavailable. Copy the link again from the app and retry in a minute.'),
        array('Is there a storage limit?',
              'Storage and file size limits depend on the app and on the storage plan behind the service, and they can change. No unlimited or permanent storage is promised.'),
        array('Does the service collect personal data?',
              'The app uses a random installation ID instead of an account, and it stores upload metadata. Read the <a href="/privacy">Privacy Policy</a> for the full list of what is stored and where.'),
        array('How do I delete an uploaded file?',
              'Use the delete option in the app\'s upload history if your version offers it. Otherwise email <a href="mailto:' . $e . '">' . $e . '</a> with the short link and the request.'),
        array('Why does my video or PDF behave differently on some phones?',
              'Videos play in your browser\'s built-in player, so format support depends on the browser. Some mobile browsers cannot show PDFs inline; there, the PDF is offered as a download instead.'),
        array('Will a link preview appear when I share it in a chat app?',
              'Often, but not always. Chat apps decide for themselves whether and when to build a preview, and they may cache the result.'),
    );
}

function faq_html($items)
{
    $o = '<div class="faq">';
    foreach ($items as $it) {
        $o .= '<details><summary>' . h($it[0]) . '</summary><p>' . $it[1] . '</p></details>';
    }
    return $o . '</div>';
}

/** Simple vertical flow diagram. $nodes = array(array(title, subtitle), ...) */
function flow_svg($nodes, $label)
{
    $w = 360; $bh = 62; $gap = 34; $n = count($nodes);
    $hgt = $n * $bh + ($n - 1) * $gap + 8;
    $s = '<svg class="flow" viewBox="0 0 ' . $w . ' ' . $hgt . '" role="img" aria-label="' . h($label) . '">';
    foreach ($nodes as $i => $nd) {
        $y = 4 + $i * ($bh + $gap);
        $s .= '<rect class="fl-box" x="20" y="' . $y . '" width="320" height="' . $bh . '" rx="12"/>';
        $s .= '<text class="fl-title" x="180" y="' . ($y + 27) . '" text-anchor="middle">' . h($nd[0]) . '</text>';
        $s .= '<text class="fl-sub" x="180" y="' . ($y + 47) . '" text-anchor="middle">' . h($nd[1]) . '</text>';
        if ($i < $n - 1) {
            $y1 = $y + $bh + 4; $y2 = $y + $bh + $gap - 4;
            $s .= '<path class="fl-arrow" d="M180 ' . $y1 . 'V' . $y2 . 'M172 ' . ($y2 - 8) . 'L180 ' . $y2 . 'L188 ' . ($y2 - 8) . '"/>';
        }
    }
    return $s . '</svg>';
}

function page_not_found()
{
    ob_start(); ?>
<section class="wrap narrow plain">
  <h1>Page not found</h1>
  <p>This page does not exist. If you were trying to open a shared file, check that the whole link was copied.</p>
  <p><a class="btn" href="/">Go to the home page</a></p>
</section>
<?php
    return array('title' => 'Page not found', 'description' => 'The requested page could not be found.', 'body' => ob_get_clean());
}

function page_home()
{
    $site = cfg('site');
    ob_start(); ?>
<section class="hero">
  <div class="wrap hero-grid">
    <div class="hero-copy">
      <h1>A short link that opens straight to your file</h1>
      <p class="lead">Photo Video URL turns images, videos, documents, files and APKs uploaded from the Android app into short web addresses. Open the address and the file appears, with nothing else on the page.</p>
      <div class="cta">
        <a class="btn" href="#download">Get the Android app</a>
        <a class="btn ghost" href="/how-it-works">See how it works</a>
      </div>
    </div>
    <div class="hero-demo" aria-hidden="true">
      <div class="browser">
        <div class="browser-bar"><span class="dots"><i></i><i></i><i></i></span><span class="addr">ivu.gt.tc/image_AaBb123</span></div>
        <div class="browser-view"><img src="/assets/img/logo-512.png" width="512" height="512" alt=""></div>
      </div>
      <p class="demo-note">Illustration of a viewer page: just the media.</p>
    </div>
  </div>
</section>

<section class="wrap block">
  <h2>What the link does depends on the file</h2>
  <p class="sub">The first part of every short ID tells the site what kind of file it is.</p>
  <div class="kinds">
    <div><code>/image_&hellip;</code><strong>Images</strong><span>Shown centered at their natural proportions on a plain background.</span></div>
    <div><code>/video_&hellip;</code><strong>Videos</strong><span>Played in a clean browser video player with controls.</span></div>
    <div><code>/document_&hellip;</code><strong>Documents</strong><span>PDFs open in the browser where it supports that; other formats download.</span></div>
    <div><code>/file_&hellip;</code><strong>Files</strong><span>Downloaded by the browser under the original file name.</span></div>
    <div><code>/apk_&hellip;</code><strong>APKs</strong><span>Downloaded only. Nothing is run or installed automatically.</span></div>
  </div>
</section>

<section class="band">
  <div class="wrap block">
    <h2>Key features</h2>
    <ul class="ticks">
      <li>Short, readable links for every upload</li>
      <li>Direct viewing with no site chrome around the media</li>
      <li>Works on phone and desktop browsers</li>
      <li>Upload history kept in the app</li>
      <li>Files stored in cloud storage, not on the website server</li>
      <li>No account required to use the app</li>
    </ul>
    <p><a href="/features">All features</a></p>
  </div>
</section>

<section class="wrap block split">
  <div>
    <h2>How it works</h2>
    <ol class="steps">
      <li><strong>Upload in the app.</strong> The file goes to Supabase Storage.</li>
      <li><strong>Get a short link.</strong> A small record for the link is saved in Firebase.</li>
      <li><strong>Share it.</strong> Anyone with the link can open it in a browser.</li>
      <li><strong>The site resolves it.</strong> It looks up the ID and shows the file directly from storage.</li>
    </ol>
    <p><a href="/how-it-works">Step-by-step guide with diagrams</a></p>
  </div>
  <div>
    <h2>Why direct media links</h2>
    <ul class="plainlist">
      <li>The recipient sees the file immediately, with no pages to click through.</li>
      <li>One short link is easy to paste into chats and messages.</li>
      <li>The browser streams media from storage, so large videos are not squeezed through this site.</li>
      <li>Links that are no longer wanted can be disabled.</li>
    </ul>
  </div>
</section>

<section id="download" class="band">
  <div class="wrap block download">
    <img src="/assets/img/logo-96.png" width="72" height="72" alt="">
    <div>
      <h2>Download the Android app</h2>
      <?php if (!empty($site['app_download_url'])): ?>
        <p>Install the official Photo Video URL app.</p>
        <p><a class="btn" href="<?php echo h($site['app_download_url']); ?>" rel="noopener">Download the app</a></p>
      <?php else: ?>
        <p>An official download link has not been published yet. It will appear here when the app is released.</p>
        <p><span class="btn off" aria-disabled="true">Download link coming soon</span></p>
      <?php endif; ?>
    </div>
  </div>
</section>

<section class="wrap block narrow">
  <h2>Common questions</h2>
  <?php echo faq_html(array_slice(faq_items(), 0, 4)); ?>
  <p><a href="/faq">More questions</a></p>
</section>
<?php
    return array(
        'title' => 'Photo Video URL - short links that open your photos, videos and files',
        'description' => 'Photo Video URL gives uploads from its Android app a short link that opens the image, video, document, file or APK directly in the browser.',
        'body' => ob_get_clean(),
    );
}

function page_about()
{
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>About Photo Video URL</h1>
  <p class="lead">Photo Video URL is an Android app and a small website that work together to turn an uploaded file into a short link anyone can open.</p>

  <h2>Why it exists</h2>
  <p>Sharing a file usually means sending an attachment or a long storage address that looks different in every service. Photo Video URL aims for something simpler: upload once, get one short link, and let the other person open the file directly in a browser.</p>

  <h2>How the Android app works</h2>
  <p>You pick an image, video, document, file or APK in the app and upload it. The app then gives you a short link. Uploads you have made on a device are listed in the app's upload history. No account or sign-in is needed; the app identifies an installation with a random ID instead.</p>

  <h2>How Supabase Storage and Firebase are used</h2>
  <p><strong>Supabase Storage</strong> holds the uploaded files. <strong>Firebase Realtime Database</strong> holds the records: the upload history for an installation and a public link record for each short URL. The public record contains the file category, its type, the storage address of the file, when it was created and whether the link is active.</p>

  <h2>How short URLs work</h2>
  <p>A short URL looks like <code>https://ivu.gt.tc/image_AaBb123</code>. The prefix is the category and the rest is a short ID. When someone opens it, this website reads the matching public link record, checks that it points to the project's storage, and shows the file. The website does not keep a copy of your file.</p>
  <p>Read more in <a href="/features">Features</a> and <a href="/how-it-works">How it works</a>, or <a href="/contact">contact us</a>.</p>
</article>
<?php
    return array('title' => 'About', 'description' => 'What Photo Video URL is, why it exists, and how the Android app, Supabase Storage, Firebase and short URLs fit together.', 'body' => ob_get_clean());
}

function page_features()
{
    ob_start(); ?>
<article class="wrap prose-wide">
  <h1>Features</h1>
  <p class="lead">What Photo Video URL provides today.</p>
  <div class="featlist">
    <section><h2>Image hosting</h2><p>Upload photos from the app. Opening the link shows only the image, scaled to fit the screen in portrait or landscape without stretching.</p></section>
    <section><h2>Video hosting</h2><p>Videos open in a clean player with play, pause and other browser controls. Playback is streamed from storage, and format support depends on your browser.</p></section>
    <section><h2>Document sharing</h2><p>PDFs open in the browser where it can display them. Other document formats are offered as a download.</p></section>
    <section><h2>File sharing</h2><p>Any other file can be shared by link and is downloaded under its original name.</p></section>
    <section><h2>APK hosting</h2><p>Share an Android package by link. It is only downloaded; the website never runs it and never installs it.</p></section>
    <section><h2>Short URL generation</h2><p>Every upload gets a short address made of a category prefix and a short ID, easy to paste into any chat.</p></section>
    <section><h2>Direct media viewing</h2><p>Media links show the media and nothing else: no menus, banners or footer.</p></section>
    <section><h2>Upload history</h2><p>The app keeps a list of your uploads on your installation so you can find your links again.</p></section>
    <section><h2>Cloud storage integration</h2><p>Files are kept in Supabase Storage and link records in Firebase Realtime Database, so nothing depends on your phone staying online.</p></section>
  </div>
  <p class="note">Not promised: permanent storage, unlimited space or uninterrupted availability. See the <a href="/disclaimer">Disclaimer</a>.</p>
</article>
<?php
    return array('title' => 'Features', 'description' => 'Image, video, document, file and APK sharing by short link, direct media viewing, upload history and cloud storage with Photo Video URL.', 'body' => ob_get_clean());
}

function page_how()
{
    $up = flow_svg(array(
        array('Android app', 'you choose a file'),
        array('Supabase Storage', 'the file is stored'),
        array('Firebase Realtime Database', 'link record is saved'),
        array('Short link', 'ivu.gt.tc/image_AaBb123'),
    ), 'Upload flow: the Android app stores the file in Supabase, saves a record in Firebase and returns a short link');
    $open = flow_svg(array(
        array('Someone opens the link', 'in any browser'),
        array('ivu.gt.tc', 'reads the ID from the address'),
        array('Firebase lookup', 'finds the public link record'),
        array('Media from storage', 'the browser loads it directly'),
    ), 'Viewing flow: the website looks up the ID in Firebase and the browser loads the file from storage');
    ob_start(); ?>
<article class="wrap prose-wide">
  <h1>How it works</h1>
  <p class="lead">From upload to a file open in someone else's browser.</p>

  <section class="how">
    <div class="how-text">
      <h2>Uploading and sharing</h2>
      <ol class="steps">
        <li><strong>Open the app and pick a file.</strong> Images, videos, documents, files and APKs are supported.</li>
        <li><strong>The file is uploaded</strong> to Supabase Storage.</li>
        <li><strong>A link record is saved</strong> in Firebase with the file's category, type and storage address.</li>
        <li><strong>You get a short link</strong> and can copy it into any chat or message.</li>
      </ol>
    </div>
    <div class="how-fig"><?php echo $up; ?></div>
  </section>

  <section class="how">
    <div class="how-text">
      <h2>Opening a link</h2>
      <ol class="steps">
        <li><strong>The visitor opens the link.</strong> The short ID is part of the address.</li>
        <li><strong>This website checks the ID</strong> and looks up its public record in Firebase.</li>
        <li><strong>The record is checked.</strong> The link must be active and point to the project's storage.</li>
        <li><strong>The file appears.</strong> Images and videos are shown; PDFs open inline where possible; other files download.</li>
      </ol>
    </div>
    <div class="how-fig"><?php echo $open; ?></div>
  </section>
  <p class="note">The website never copies your file. The browser fetches it directly from storage.</p>
</article>
<?php
    return array('title' => 'How it works', 'description' => 'Step-by-step: how a file uploaded in the Photo Video URL app becomes a short link and how that link opens the file.', 'body' => ob_get_clean());
}

function page_terms()
{
    $s = cfg('site'); $e = h($s['support_email']);
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>Terms and Conditions</h1>
  <p class="meta">Last updated: <?php echo h($s['last_updated']); ?></p>

  <h2>1. Acceptance of terms</h2>
  <p>By using the Photo Video URL Android app, this website or any short link, you agree to these terms. If you do not agree, do not use the service.</p>

  <h2>2. Acceptable use</h2>
  <p>Use the service lawfully and only for content you have the right to share. Do not use it in a way that harms other people, the service or its providers.</p>

  <h2>3. Your responsibility for uploaded content</h2>
  <p>You are solely responsible for everything you upload and for every link you share. Upload only content you own or have permission to share. Uploading a file does not give you any rights in it that you did not already have.</p>

  <h2>4. Copyright and intellectual property</h2>
  <p>The service does not claim ownership of your uploads, and you must not upload material that infringes someone else's copyright, trademark or other rights. The Photo Video URL name, logo and website design belong to the service operator. To report an infringement, write to the address in section 13 and include the short link and a description of the rights concerned.</p>

  <h2>5. Prohibited content and activities</h2>
  <p>You may not upload or share:</p>
  <ul>
    <li>content that is illegal where you or the recipients live, or that sexually exploits or endangers children;</li>
    <li>malware, or files meant to damage devices or steal data;</li>
    <li>content that infringes copyright or other rights;</li>
    <li>content used for harassment, fraud, impersonation or threats.</li>
  </ul>
  <p>You also may not try to disrupt the service, probe it for weaknesses, or access data that is not yours.</p>

  <h2>6. Public link sharing</h2>
  <p>A short link is public. Anyone who has the link can open the file, and links can be forwarded by the people you send them to. Do not upload anything you would not want a link holder to see.</p>

  <h2>7. Storage limitations</h2>
  <p>Storage space and file sizes are limited, and the limits can change. Files may be unavailable, and permanent storage is not guaranteed. Keep your own copy of anything important.</p>

  <h2>8. Account-free usage and installation identification</h2>
  <p>No account is needed. The app instead uses a random installation ID to keep your upload history together on your installation. If you reinstall the app or clear its data, you may lose access to that history.</p>

  <h2>9. Link suspension and removal</h2>
  <p>A link or file may be disabled or removed without notice if it appears to break these terms, if we receive a valid complaint, or if the law requires it. You can ask for your own links to be removed by contacting us.</p>

  <h2>10. Service availability</h2>
  <p>The service is provided as it is and as available. It can be interrupted or changed, and it relies on third-party providers whose availability we do not control.</p>

  <h2>11. Limitation of liability</h2>
  <p>To the extent the law allows, the service operator is not liable for lost or unavailable files, for content uploaded by users, or for indirect or consequential loss arising from use of the service. Nothing here limits liability that cannot be limited by law.</p>

  <h2>12. Changes to these terms</h2>
  <p>These terms may be updated. The date above shows the latest revision. Continuing to use the service after a change means you accept the updated terms.</p>

  <h2>13. Contact</h2>
  <p>Questions, complaints and removal requests: <a href="mailto:<?php echo $e; ?>"><?php echo $e; ?></a>. See also the <a href="/privacy">Privacy Policy</a> and <a href="/disclaimer">Disclaimer</a>.</p>
</article>
<?php
    return array('title' => 'Terms and Conditions', 'description' => 'The terms for using the Photo Video URL app, website and short links, including acceptable use, uploaded content and public link sharing.', 'body' => ob_get_clean());
}

function page_privacy()
{
    $s = cfg('site'); $e = h($s['support_email']);
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>Privacy Policy</h1>
  <p class="meta">Last updated: <?php echo h($s['last_updated']); ?></p>
  <p>This policy explains what the Photo Video URL Android app and website store. The service does not claim that no data is collected: uploads and their metadata are stored so that links can work.</p>

  <h2>What the Android app collects</h2>
  <ul>
    <li>The files you choose to upload.</li>
    <li>Metadata about each upload, such as its category, file type, storage location and creation time.</li>
    <li>A randomly generated installation ID, used instead of an account.</li>
  </ul>

  <h2>What is stored in Firebase</h2>
  <p>Firebase Realtime Database stores upload records connected to an installation ID (your upload history) and a public link record for each short URL: file category, type, storage address, creation time and whether the link is active.</p>

  <h2>What is stored in Supabase</h2>
  <p>Supabase Storage stores the uploaded files themselves.</p>

  <h2>How upload history works</h2>
  <p>The app lists the uploads linked to your installation ID so you can find your links again. There is no account, so the history is tied to the installation, not to a person.</p>

  <h2>How public URLs work and what is public</h2>
  <p>Every short link is public. Anyone who has the link can open the file. The website reads only the public link record. It does not display or expose installation IDs, upload histories, or other app data. The storage address in the public record points to a publicly readable file, so someone who knows that address can open the file without this website.</p>

  <h2>Local configuration storage</h2>
  <p>The app keeps its settings and the installation ID on your device. Clearing the app's data removes them. The website sets no cookies and loads no analytics or advertising scripts on media pages.</p>

  <h2>Server logs and caching</h2>
  <p>Our web host processes requests to this website and may keep standard server logs, such as IP address and requested address, under its own policy. To keep pages fast, the website briefly caches the public link record (for about a minute) on its server. It does not cache your files.</p>

  <h2>Data retention and deletion</h2>
  <p>Records and files are kept until they are deleted or the service is changed. No fixed retention period is promised. To have an upload removed, use the delete option in the app if your version offers one, or email <a href="mailto:<?php echo $e; ?>"><?php echo $e; ?></a> with the short link. Disabling a link stops it from opening; cached copies held by others (for example in chat previews or downloads) are outside our control.</p>

  <h2>Third-party service providers</h2>
  <ul>
    <li><strong>Google Firebase</strong> for the database.</li>
    <li><strong>Supabase</strong> for file storage.</li>
    <li><strong>InfinityFree</strong> for web hosting.</li>
  </ul>
  <p>Each provider handles data under its own terms and privacy policy.</p>

  <h2>Contact and privacy requests</h2>
  <p>To ask what is stored, or to request correction or deletion, write to <a href="mailto:<?php echo $e; ?>"><?php echo $e; ?></a>. Please include the short link concerned.</p>
</article>
<?php
    return array('title' => 'Privacy Policy', 'description' => 'What data the Photo Video URL app collects, what is stored in Firebase and Supabase, what is public, and how to request deletion.', 'body' => ob_get_clean());
}

function page_disclaimer()
{
    $e = h(cfg('site')['support_email']);
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>Disclaimer</h1>
  <ul class="bigpoints">
    <li><strong>You are responsible for what you upload.</strong> Photo Video URL does not review uploads before they are shared.</li>
    <li><strong>It is a file hosting and sharing service.</strong> It is not a backup service, an archive or a legal record.</li>
    <li><strong>Public links are open.</strong> Anyone who receives a link may be able to open it, and may pass it on.</li>
    <li><strong>No guarantees.</strong> Permanent storage and uninterrupted availability are not guaranteed. Keep your own copies.</li>
    <li><strong>Complaints.</strong> Copyright and other legal complaints can be sent through the <a href="/contact">contact page</a> (<a href="mailto:<?php echo $e; ?>"><?php echo $e; ?></a>). Include the short link.</li>
  </ul>
  <p>See also the <a href="/terms">Terms and Conditions</a> and <a href="/privacy">Privacy Policy</a>.</p>
</article>
<?php
    return array('title' => 'Disclaimer', 'description' => 'Photo Video URL is a file hosting and sharing service. Users are responsible for uploads; public links are open and availability is not guaranteed.', 'body' => ob_get_clean());
}

function page_contact()
{
    $e = h(cfg('site')['support_email']);
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>Contact</h1>
  <p class="lead">Support, privacy requests, removal requests and legal complaints all go to one address.</p>
  <p class="mail"><a href="mailto:<?php echo $e; ?>"><?php echo $e; ?></a></p>
  <h2>What to include</h2>
  <ul>
    <li>The short link concerned, for example <code>https://ivu.gt.tc/image_AaBb123</code>.</li>
    <li>What you want us to do: help, remove, or look into a complaint.</li>
    <li>For a copyright complaint: what work is affected and how you are connected to it.</li>
  </ul>
  <p>There is no contact form on this website; please send an email.</p>
</article>
<?php
    return array('title' => 'Contact', 'description' => 'Contact Photo Video URL for support, privacy requests, link removal and copyright complaints.', 'body' => ob_get_clean());
}

function page_faq()
{
    ob_start(); ?>
<article class="wrap narrow prose">
  <h1>Frequently asked questions</h1>
  <?php echo faq_html(faq_items()); ?>
  <p>Still stuck? <a href="/contact">Contact us</a>.</p>
</article>
<?php
    return array('title' => 'FAQ', 'description' => 'Answers about uploading, short URLs, Supabase storage, public viewing, broken links, storage limits, privacy and deleting files.', 'body' => ob_get_clean());
}
