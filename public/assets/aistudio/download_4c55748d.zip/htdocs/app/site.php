<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

/* Main informational website (separate layout from the media viewer). */

require_once APP_ROOT . '/app/pages.php';

function info_routes()
{
    return array(
        '/'             => 'page_home',
        '/about'        => 'page_about',
        '/features'     => 'page_features',
        '/how-it-works' => 'page_how',
        '/terms'        => 'page_terms',
        '/privacy'      => 'page_privacy',
        '/disclaimer'   => 'page_disclaimer',
        '/contact'      => 'page_contact',
        '/faq'          => 'page_faq',
    );
}

function nav_links()
{
    return array('/' => 'Home', '/features' => 'Features', '/how-it-works' => 'How it works', '/about' => 'About');
}

function footer_links()
{
    return array(
        '/about' => 'About', '/features' => 'Features', '/faq' => 'FAQ',
        '/terms' => 'Terms and Conditions', '/privacy' => 'Privacy Policy',
        '/disclaimer' => 'Disclaimer', '/contact' => 'Contact',
    );
}

function render_site_page($path, $page, $status = 200)
{
    $site = cfg('site');
    http_response_code($status);
    header('Content-Type: text/html; charset=UTF-8');
    send_common_headers();
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'self'; form-action 'none'; frame-ancestors 'self'");
    header($status === 200 ? 'Cache-Control: public, max-age=300' : 'Cache-Control: no-store');
    if ($status !== 200) { header('X-Robots-Tag: noindex'); }

    $canon = $site['site_url'] . ($path === '/' ? '/' : $path);
    $fullTitle = $path === '/' ? $page['title'] : $page['title'] . ' | ' . $site['site_name'];

    $nav = '';
    foreach (nav_links() as $href => $label) {
        $cur = ($href === $path) ? ' aria-current="page"' : '';
        $nav .= '<a href="' . h($href) . '"' . $cur . '>' . h($label) . '</a>';
    }
    $foot = '';
    foreach (footer_links() as $href => $label) {
        $foot .= '<a href="' . h($href) . '">' . h($label) . '</a>';
    }

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>' . h($fullTitle) . '</title>'
       . '<meta name="description" content="' . h($page['description']) . '">'
       . ($status === 200 ? '<link rel="canonical" href="' . h($canon) . '">' : '<meta name="robots" content="noindex">')
       . '<meta name="theme-color" content="#0b1530"><meta name="color-scheme" content="dark">'
       . '<meta property="og:site_name" content="' . h($site['site_name']) . '">'
       . '<meta property="og:title" content="' . h($fullTitle) . '">'
       . '<meta property="og:description" content="' . h($page['description']) . '">'
       . '<meta property="og:type" content="website"><meta property="og:url" content="' . h($canon) . '">'
       . '<meta property="og:image" content="' . h($site['site_url']) . '/assets/img/og-image.png">'
       . '<meta name="twitter:card" content="summary_large_image">'
       . '<link rel="icon" href="/favicon.ico" sizes="any"><link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png">'
       . '<link rel="stylesheet" href="/assets/css/site.css"></head><body>'
       . '<a class="skip" href="#main">Skip to content</a>'
       . '<header class="top"><div class="wrap bar">'
       . '<a class="brand" href="/"><img src="/assets/img/logo-96.png" width="40" height="40" alt="">'
       . '<span>' . h($site['site_name']) . '</span></a>'
       . '<button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav"><span class="sr">Menu</span>'
       . '<svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><path d="M3 6h16M3 11h16M3 16h16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>'
       . '<nav id="nav" class="nav" aria-label="Main">' . $nav . '</nav>'
       . '</div></header>'
       . '<main id="main">' . $page['body'] . '</main>'
       . '<footer class="foot"><div class="wrap">'
       . '<div class="foot-brand"><img src="/assets/img/logo-96.png" width="32" height="32" alt=""><span>' . h($site['site_name']) . '</span></div>'
       . '<nav class="foot-nav" aria-label="Footer">' . $foot . '</nav>'
       . '<p class="fine">&copy; ' . date('Y') . ' ' . h($site['site_name']) . '. Files are the responsibility of the people who upload them.</p>'
       . '</div></footer>'
       . '<script src="/assets/js/site.js" defer></script></body></html>';
}

function serve_info_page($path)
{
    $routes = info_routes();
    if (!isset($routes[$path])) {
        render_site_page('/404', page_not_found(), 404);
        return;
    }
    $fn = $routes[$path];
    render_site_page($path, $fn(), 200);
}
