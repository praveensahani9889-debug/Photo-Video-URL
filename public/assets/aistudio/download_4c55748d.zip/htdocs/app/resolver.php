<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

/** Turn the raw Firebase node into a normalised record (adjust key names here if your app differs). */
function normalize_record($raw)
{
    $pick = function ($keys) use ($raw) {
        foreach ($keys as $k) {
            if (isset($raw[$k]) && is_string($raw[$k]) && $raw[$k] !== '') { return $raw[$k]; }
        }
        return '';
    };
    $url = $pick(array('originalUrl', 'supabaseUrl', 'url'));
    if ($url === '') { return null; }

    $a = array_key_exists('active', $raw) ? $raw['active'] : true;
    $active = true;
    if ($a === false || $a === 0 || $a === '0' || (is_string($a) && strtolower($a) === 'false')) { $active = false; }

    $type = strtolower($pick(array('fileType', 'type')));
    return array(
        'active' => $active,
        'type'   => $type === '' ? null : $type,
        'mime'   => strtolower($pick(array('mimeType', 'mime'))),
        'url'    => $url,
        'path'   => $pick(array('storagePath')),
        'name'   => $pick(array('fileName')),
    );
}

/** Cached lookup. Returns array('state' => ok|missing|error, 'record' => array|null) */
function lookup_link($id)
{
    $site = cfg('site');
    $key = 'link_' . $id;
    $hit = cache_get($key);
    if ($hit !== null) {
        return $hit['v'] === null ? array('state' => 'missing', 'record' => null)
                                  : array('state' => 'ok', 'record' => $hit['v']);
    }

    $res = firebase_get_link($id);
    if ($res['state'] === 'error') { return array('state' => 'error', 'record' => null); }

    $rec = $res['state'] === 'ok' ? normalize_record($res['data']) : null;
    if ($rec === null) {
        cache_set($key, null, (int)$site['negative_ttl']);
        return array('state' => 'missing', 'record' => null);
    }
    cache_set($key, $rec, $rec['active'] ? (int)$site['cache_ttl'] : (int)$site['negative_ttl']);
    return array('state' => 'ok', 'record' => $rec);
}

function send_error($status, $message = '')
{
    $file = array(400 => '400', 404 => '404', 410 => '410', 415 => '400', 503 => '503');
    $f = isset($file[$status]) ? $file[$status] : '404';
    $errorStatus = $status;
    $errorMessage = $message;
    require APP_ROOT . '/errors/' . $f . '.php';
    exit;
}

function resolve_media($m)
{
    $id = $m['id'];
    $type = $m['type'];

    $res = lookup_link($id);
    if ($res['state'] === 'error')   { send_error(503); }
    if ($res['state'] === 'missing') { send_error(404); }

    $rec = $res['record'];
    if (!$rec['active'])                         { send_error(410); }
    if ($rec['type'] !== null && $rec['type'] !== $type) { send_error(404); }
    if (!is_allowed_storage_url($rec['url'])) {
        log_internal('rejected storage url for ' . $id);
        send_error(404);
    }
    handle_media($id, $type, $rec);
}
