<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

function cfg($name)
{
    static $cache = array();
    if (!in_array($name, array('firebase', 'site'), true)) { return array(); }
    if (!isset($cache[$name])) {
        $cache[$name] = require APP_ROOT . '/config/' . $name . '.php';
    }
    return $cache[$name];
}

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Normalised request path, or null when the path is unsafe. */
function request_path()
{
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    $p = parse_url($uri, PHP_URL_PATH);
    if (!is_string($p) || $p === '') { return '/'; }
    $p = rawurldecode($p);
    if (preg_match('/[\x00-\x1f\x7f\\\\]/', $p) || strpos($p, '..') !== false) { return null; }
    $p = preg_replace('#/+#', '/', $p);
    if ($p !== '/') { $p = rtrim($p, '/'); }
    return $p === '' ? '/' : $p;
}

/** Strict allowlist for short IDs: image_xxx, video_xxx, document_xxx, file_xxx, apk_xxx */
function parse_media_id($path)
{
    if (preg_match('#^/((image|video|document|file|apk)_[A-Za-z0-9_-]{3,64})$#D', $path, $m)) {
        return array('id' => $m[1], 'type' => $m[2]);
    }
    return null;
}

/** Only HTTPS Supabase public-storage URLs are ever used or redirected to. */
function is_allowed_storage_url($url)
{
    if (!is_string($url) || $url === '' || strlen($url) > 2048) { return false; }
    if (preg_match('/[\x00-\x20\x7f"\'<>\\\\`]/', $url)) { return false; }
    $u = parse_url($url);
    if (!is_array($u) || !isset($u['scheme'], $u['host'], $u['path'])) { return false; }
    if (strtolower($u['scheme']) !== 'https') { return false; }
    if (isset($u['user']) || isset($u['pass']) || isset($u['fragment'])) { return false; }
    if (isset($u['port']) && (int)$u['port'] !== 443) { return false; }

    $host = strtolower($u['host']);
    $site = cfg('site');
    if (!empty($site['supabase_host'])) {
        if ($host !== strtolower($site['supabase_host'])) { return false; }
    } elseif (!preg_match('/^[a-z0-9]([a-z0-9-]{1,61})[a-z0-9]\.supabase\.co$/', $host)) {
        return false;
    }

    $path = $u['path'];
    if (strpos($path, '/storage/v1/object/public/') !== 0) { return false; }
    if (preg_match('#(^|/)(\.|%2e){2}(/|$)#i', $path)) { return false; }
    return true;
}

function allowed_media_host_csp()
{
    $site = cfg('site');
    return !empty($site['supabase_host']) ? 'https://' . $site['supabase_host'] : 'https://*.supabase.co';
}

function safe_filename($name, $fallback = 'download')
{
    $name = (string)$name;
    $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
    $name = str_replace(array('/', '\\', '"', "'", ':', '*', '?', '<', '>', '|'), '_', $name);
    $clean = @preg_replace('/[^\p{L}\p{N} ._()\-]/u', '_', $name);
    if (!is_string($clean)) { $clean = preg_replace('/[^A-Za-z0-9 ._()\-]/', '_', $name); }
    $clean = trim($clean, " .");
    if (function_exists('mb_substr')) { $clean = mb_substr($clean, 0, 120, 'UTF-8'); } else { $clean = substr($clean, 0, 120); }
    return $clean === '' ? $fallback : $clean;
}

function mime_from_extension($name)
{
    $ext = strtolower(pathinfo((string)$name, PATHINFO_EXTENSION));
    $map = array(
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'avif' => 'image/avif', 'bmp' => 'image/bmp', 'svg' => 'image/svg+xml',
        'mp4' => 'video/mp4', 'm4v' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime',
        'mkv' => 'video/x-matroska', '3gp' => 'video/3gpp', 'ogv' => 'video/ogg',
        'pdf' => 'application/pdf',
        'apk' => 'application/vnd.android.package-archive',
    );
    return isset($map[$ext]) ? $map[$ext] : '';
}

function valid_mime($mime)
{
    return is_string($mime) && preg_match('#^[a-z0-9][a-z0-9.+-]{0,60}/[a-z0-9][a-z0-9.+-]{0,100}$#', $mime) === 1;
}

function send_common_headers()
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
}

function log_internal($msg)
{
    @error_log('[ivu] ' . $msg);
}
