<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

/**
 * Read one public link record through the Firebase Realtime Database REST API.
 * Returns array('state' => 'ok'|'missing'|'error', 'data' => array|null)
 */
function firebase_get_link_at($id, $linksPath)
{
    $fb = cfg('firebase');
    $site = cfg('site');
    if (!preg_match('/^[A-Za-z0-9_-]{1,100}$/', $id)) { return array('state' => 'missing', 'data' => null); }

    $url = rtrim($fb['databaseURL'], '/') . '/' . $linksPath . '/' . rawurlencode($id) . '.json';
    $timeout = isset($site['http_timeout']) ? (int)$site['http_timeout'] : 6;

    $body = null;
    $code = 0;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS,
            CURLOPT_HTTPHEADER     => array('Accept: application/json'),
            CURLOPT_USERAGENT      => 'PhotoVideoURL-Resolver/1.0',
            CURLOPT_MAXFILESIZE    => 262144,
        ));
        $resp = curl_exec($ch);
        if ($resp === false) {
            log_internal('curl error: ' . curl_error($ch));
        } else {
            $body = $resp;
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        }
        curl_close($ch);
    } else {
        $ctx = stream_context_create(array('http' => array(
            'method' => 'GET', 'timeout' => $timeout, 'ignore_errors' => true,
            'header' => "Accept: application/json\r\nUser-Agent: PhotoVideoURL-Resolver/1.0\r\n",
        ), 'ssl' => array('verify_peer' => true, 'verify_peer_name' => true)));
        $resp = @file_get_contents($url, false, $ctx);
        if ($resp !== false) {
            $body = $resp;
            if (isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) { $code = (int)$m[1]; }
        }
    }

    if ($body === null) { return array('state' => 'error', 'data' => null); }
    if ($code === 401 || $code === 403) { log_internal('firebase permission denied - check database rules'); return array('state' => 'error', 'data' => null); }
    if ($code !== 200) { log_internal('firebase http ' . $code); return array('state' => 'error', 'data' => null); }

    $data = json_decode($body, true);
    if ($data === null && trim($body) !== 'null') { log_internal('firebase invalid json'); return array('state' => 'error', 'data' => null); }
    if (!is_array($data)) { return array('state' => 'missing', 'data' => null); }
    return array('state' => 'ok', 'data' => $data);
}

/** Tries each configured links path in order (the app writes to root "public_links"). */
function firebase_get_link($id)
{
    $fb = cfg('firebase');
    $hadError = false;
    foreach ($fb['links_paths'] as $path) {
        $res = firebase_get_link_at($id, $path);
        if ($res['state'] === 'ok') { return $res; }
        if ($res['state'] === 'error') { $hadError = true; }
    }
    return array('state' => $hadError ? 'error' : 'missing', 'data' => null);
}
