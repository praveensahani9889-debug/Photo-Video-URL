<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

/* Tiny file cache for Firebase metadata only (never media). */

function cache_dir()
{
    $dir = APP_ROOT . '/cache';
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
    return (is_dir($dir) && is_writable($dir)) ? $dir : null;
}

function cache_file($key)
{
    $dir = cache_dir();
    return $dir === null ? null : $dir . '/m_' . sha1($key) . '.json';
}

function cache_get($key)
{
    $f = cache_file($key);
    if ($f === null || !is_file($f)) { return null; }
    $raw = @file_get_contents($f);
    $d = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($d) || !isset($d['exp']) || $d['exp'] < time() || !array_key_exists('v', $d)) {
        @unlink($f);
        return null;
    }
    return array('v' => $d['v']);
}

function cache_set($key, $value, $ttl)
{
    $f = cache_file($key);
    if ($f === null || $ttl <= 0) { return; }
    $tmp = $f . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, json_encode(array('exp' => time() + (int)$ttl, 'v' => $value)), LOCK_EX) !== false) {
        @rename($tmp, $f);
    }
    if (mt_rand(1, 100) === 1) { cache_gc(); }
}

function cache_gc()
{
    $dir = cache_dir();
    if ($dir === null) { return; }
    foreach ((array)@glob($dir . '/m_*') as $f) {
        if (@filemtime($f) < time() - 3600) { @unlink($f); }
    }
}
