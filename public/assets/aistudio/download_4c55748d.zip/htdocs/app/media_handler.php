<?php
if (!defined('APP_ROOT')) { http_response_code(403); exit; }

function record_filename($rec, $type)
{
    $src = (!empty($rec['name'])) ? $rec['name'] : ($rec['path'] !== '' ? $rec['path'] : (string)parse_url($rec['url'], PHP_URL_PATH));
    $name = safe_filename(rawurldecode(basename($src)));
    if ($type === 'apk' && strtolower(substr($name, -4)) !== '.apk') { $name .= '.apk'; }
    return $name;
}

function download_url($rec, $name)
{
    $base = preg_replace('/([?&])download=[^&]*&?/', '$1', $rec['url']);
    $base = rtrim($base, '?&');
    $url = $base . (strpos($base, '?') === false ? '?' : '&') . 'download=' . rawurlencode($name);
    return is_allowed_storage_url($url) ? $url : null;
}

function handle_media($id, $type, $rec)
{
    $name = record_filename($rec, $type);
    $mime = valid_mime($rec['mime']) ? $rec['mime'] : mime_from_extension($name);
    if ($mime === '') { $mime = mime_from_extension((string)parse_url($rec['url'], PHP_URL_PATH)); }
    if ($mime === 'application/octet-stream') {
        $guess = mime_from_extension($name);
        if ($guess === '') { $guess = mime_from_extension((string)parse_url($rec['url'], PHP_URL_PATH)); }
        if ($guess !== '') { $mime = $guess; }
    }

    if ($type === 'image') {
        if ($mime !== '' && strpos($mime, 'image/') !== 0) { send_error(415); }
        render_image($id, $rec, $name, $mime);
    } elseif ($type === 'video') {
        if ($mime !== '' && strpos($mime, 'video/') !== 0) { send_error(415); }
        render_video($id, $rec, $name, $mime !== '' ? $mime : 'video/mp4');
    } elseif ($type === 'document' && $mime === 'application/pdf') {
        render_pdf($id, $rec, $name);
    } else {
        // document (non-PDF), file, apk: browser download, never executed or installed by us
        $dl = download_url($rec, $name);
        if ($dl === null) { send_error(404); }
        header('Cache-Control: private, no-cache, max-age=0');
        header('X-Robots-Tag: noindex, nofollow');
        send_common_headers();
        header('Location: ' . $dl, true, 302);
        exit;
    }
}

/** Minimal viewer shell: no site header, nav or footer. */
function render_viewer($opts)
{
    $site = cfg('site');
    $host = allowed_media_host_csp();
    $status = isset($opts['status']) ? (int)$opts['status'] : 200;
    http_response_code($status);
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Robots-Tag: noindex, nofollow');
    send_common_headers();
    header("Content-Security-Policy: default-src 'none'; img-src $host data:; media-src $host; frame-src $host; style-src 'self'; script-src 'self'; base-uri 'none'; form-action 'none'");
    header($status === 200 ? 'Cache-Control: public, max-age=60, must-revalidate'
                           : 'Cache-Control: no-store');

    $og = '';
    if (!empty($opts['og'])) {
        foreach ($opts['og'] as $prop => $val) {
            $og .= '<meta property="' . h($prop) . '" content="' . h($val) . "\">\n";
        }
    }
    $title = h($opts['title']);
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="robots" content="noindex,nofollow"><meta name="theme-color" content="#1e1e1e">'
       . '<title>' . $title . '</title>' . "\n" . $og
       . '<link rel="icon" href="/favicon.ico"><link rel="stylesheet" href="/assets/css/viewer.css">'
       . '</head><body class="' . h($opts['class']) . '">' . $opts['body']
       . '<script src="/assets/js/viewer.js" defer></script></body></html>';
}

function base_og($id, $name, $type)
{
    $site = cfg('site');
    return array(
        'og:site_name'   => $site['site_name'],
        'og:title'       => $name,
        'og:description' => 'Shared with ' . $site['site_name'],
        'og:url'         => $site['site_url'] . '/' . $id,
        'og:type'        => $type,
    );
}

function render_image($id, $rec, $name, $mime)
{
    $og = base_og($id, $name, 'website');
    $og['og:image'] = $rec['url'];
    $og['og:image:secure_url'] = $rec['url'];
    if ($mime !== '') { $og['og:image:type'] = $mime; }
    $og['og:image:alt'] = $name;
    $og['twitter:card'] = 'summary_large_image';
    render_viewer(array(
        'title' => $name, 'class' => 'v-image', 'og' => $og,
        'body'  => '<img src="' . h($rec['url']) . '" alt="' . h($name) . '" decoding="async" referrerpolicy="no-referrer">'
                 . '<p id="msg" class="msg" hidden>This image could not be loaded.</p>',
    ));
}

function render_video($id, $rec, $name, $mime)
{
    $og = base_og($id, $name, 'video.other');
    $og['og:video'] = $rec['url'];
    $og['og:video:secure_url'] = $rec['url'];
    $og['og:video:type'] = $mime;
    render_viewer(array(
        'title' => $name, 'class' => 'v-video', 'og' => $og,
        'body'  => '<video controls playsinline preload="metadata" referrerpolicy="no-referrer">'
                 . '<source src="' . h($rec['url']) . '" type="' . h($mime) . '">'
                 . 'Your browser cannot play this video.</video>'
                 . '<p id="msg" class="msg" hidden>This video could not be loaded.</p>',
    ));
}

function render_pdf($id, $rec, $name)
{
    $dl = download_url($rec, $name);
    $og = base_og($id, $name, 'website');
    render_viewer(array(
        'title' => $name, 'class' => 'v-doc', 'og' => $og,
        'body'  => '<iframe src="' . h($rec['url']) . '" title="' . h($name) . '" referrerpolicy="no-referrer"'
                 . ($dl ? ' data-dl="' . h($dl) . '"' : '') . '></iframe>'
                 . ($dl ? '<a class="dl" href="' . h($dl) . '">Download PDF</a>' : ''),
    ));
}
